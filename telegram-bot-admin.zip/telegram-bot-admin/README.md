# Telegram Xabarnoma Boti — Admin Panel

Telegram botingizni boshqarish uchun to'liq ishlaydigan admin panel. Foydalanuvchilarni boshqarish, guruhlarga bo'lish, rasm/fayl bilan xabar yuborish, vaqt belgilab rejalashtirish, tugmali xabarlar va ko'p admin tizimi bilan.

## Funksiyalar

- 📊 Statistika va kunlik o'sish grafigi
- 👥 Foydalanuvchilarni ko'rish, bloklash, o'chirish
- 🏷️ Foydalanuvchilarni guruhlarga bo'lish (masalan VIP, yangi, faol)
- 📢 Xabar yuborish: hammaga / guruhga / tanlangan foydalanuvchilarga
- 📎 Xabarga rasm, video yoki hujjat qo'shish
- 🔘 Inline tugmalar (URL havola yoki bosish statistikasi bilan)
- ⏰ Xabarni kelajakdagi sana/vaqtga rejalashtirish
- 🔐 Bir nechta admin, rollar bilan (admin / super-admin)
- 📜 Yuborilgan va rejalashtirilgan xabarlar tarixi

## Tarkibi

- **Backend**: Node.js + Express
- **Bot**: node-telegram-bot-api (polling rejimida)
- **Baza**: SQLite (better-sqlite3) — alohida server kerak emas
- **Rejalashtiruvchi**: node-cron (har minutda tekshiradi)
- **Fayl yuklash**: multer
- **Frontend**: HTML/CSS/JS + Chart.js (grafiklar uchun)

## O'rnatish

### 1. Bog'liqliklarni o'rnating

```bash
npm install
```

### 2. Bot tokenini oling

1. Telegram'da [@BotFather](https://t.me/BotFather)ga yozing
2. `/newbot` buyrug'ini yuboring va ko'rsatmalarga amal qiling
3. Sizga token beriladi, masalan: `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`

### 3. `.env` faylini sozlang

```bash
cp .env.example .env
```

`.env` faylini ochib to'ldiring:

```
BOT_TOKEN=sizning_bot_tokeningiz
ADMIN_PASSWORD=xavfsiz_parol_qoying
PORT=3000
```

`ADMIN_PASSWORD` — birinchi marta ishga tushganda yaratiladigan standart super-admin paroli. Standart login: **admin**

**Muhim**: `ADMIN_PASSWORD`ni albatta o'zgartiring.

### 4. Serverni ishga tushiring

```bash
npm start
```

Konsolda:
```
Admin panel ishlamoqda: http://localhost:3000
Telegram bot ishga tushdi...
Rejalashtiruvchi (scheduler) ishga tushdi...
```

### 5. Admin panelga kiring

`http://localhost:3000` ni oching, login: `admin`, parol: `.env`da belgilagan qiymat.

## Qanday ishlaydi

1. Foydalanuvchi botga `/start` yuborganda avtomatik bazaga qo'shiladi
2. **Guruhlar** bo'limida guruh yaratasiz (masalan "VIP"), keyin **Foydalanuvchilar** bo'limida har bir kishini kerakli guruh(lar)ga biriktirasiz
3. **Xabar yuborish** bo'limida: matn yozasiz, ixtiyoriy rasm/fayl qo'shasiz, ixtiyoriy tugmalar qo'shasiz, va kimga (hammaga / guruhga / tanlangan kishilarga) yuborishni belgilaysiz
4. Agar darhol emas, keyinroq yuborish kerak bo'lsa — "Vaqt belgilab yuborish" qutisini belgilab sana/vaqt tanlaysiz. Scheduler har minutda tekshirib, vaqti kelganda avtomatik yuboradi
5. Tugmali xabarlar uchun: agar tugmada URL bo'lsa — havola tugmasi; bo'lmasa — bosilganda statistikaga yoziladi (Tarix bo'limida "Bosishlar" ustunida ko'rinadi)
6. **Adminlar** bo'limi (faqat super-admin ko'radi) — yangi admin qo'shish/o'chirish, ularga oddiy `admin` yoki `super_admin` rolini berish

## Bot buyruqlari (foydalanuvchilar uchun)

- `/start` — botga obuna bo'lish
- `/stop` — obunani bekor qilish

## Production'ga deploy qilish

- **Railway** / **Render** — eng oson, bepul tarif mavjud
- **VPS** (DigitalOcean, Hetzner) + PM2 process manager
- **Fly.io**

Eslatmalar:
- SQLite fayl asosida ishlagani uchun, bitta instансdan foydalanish tavsiya etiladi
- Yuklangan fayllar `uploads/` papkasida saqlanadi — VPS qayta ishga tushganda bu papka saqlanib qolishini ta'minlang (Railway/Render kabi "ephemeral" muhitlarda restart paytida fayllar yo'qolishi mumkin, shu sabab uzoq muddatli loyiha uchun S3 kabi tashqi saqlash tavsiya etiladi)

## Xavfsizlik eslatmalari

- `.env` faylini hech qachon git'ga qo'shmang (`.gitignore`da allaqachon bor)
- `ADMIN_PASSWORD`ni kuchli parol bilan almashtiring
- Adminlar jadvalidagi parollar hozircha tekst ko'rinishida saqlanadi (oddiylik uchun) — production uchun bcrypt bilan hash qilishni tavsiya qilamiz
- Production muhitda HTTPS ishlatishni unutmang

## Loyiha tuzilishi

```
telegram-bot-admin/
├── server.js          # Asosiy server fayli (auth, middleware)
├── bot.js             # Telegram bot logikasi (xabar, fayl, tugma)
├── scheduler.js       # Rejalashtirilgan xabarlarni yuboruvchi
├── db/
│   └── database.js    # SQLite sozlamalari va jadvallar
├── routes/
│   └── api.js         # Barcha API endpoint'lari
├── public/
│   ├── index.html     # Admin panel HTML
│   └── app.js         # Admin panel frontend mantiqi
├── uploads/           # Yuklangan rasm/fayllar (avtomatik yaratiladi)
├── .env.example
└── package.json
```

