const TelegramBot = require('node-telegram-bot-api');
const db = require('../db/database');

let bot = null;

function initBot(token) {
  bot = new TelegramBot(token, { polling: true });

  // /start buyrug'i - foydalanuvchini bazaga qo'shish
  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const { username, first_name, last_name } = msg.from;

    const existing = db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(chatId);

    if (!existing) {
      db.prepare(`
        INSERT INTO users (telegram_id, username, first_name, last_name)
        VALUES (?, ?, ?, ?)
      `).run(chatId, username || null, first_name || null, last_name || null);

      bot.sendMessage(chatId, `Salom, ${first_name || 'foydalanuvchi'}! Siz xabarnomalarga muvaffaqiyatli yozildingiz.`);
    } else {
      if (existing.is_blocked) {
        db.prepare('UPDATE users SET is_blocked = 0 WHERE telegram_id = ?').run(chatId);
      }
      bot.sendMessage(chatId, `Qaytib kelganingizdan xursandmiz, ${first_name || ''}!`);
    }
  });

  // /stop buyrug'i - foydalanuvchi obunani bekor qilishi
  bot.onText(/\/stop/, (msg) => {
    const chatId = msg.chat.id;
    db.prepare('UPDATE users SET is_blocked = 1 WHERE telegram_id = ?').run(chatId);
    bot.sendMessage(chatId, 'Siz xabarnomalardan voz kechdingiz. Qaytadan yozilish uchun /start ni bosing.');
  });

  // Inline tugma bosilganda - callback_query'ni qayd etish
  bot.on('callback_query', (query) => {
    const chatId = query.message.chat.id;
    const user = db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(chatId);

    // Callback data formati: "broadcastId::buttonText"
    const parts = (query.data || '').split('::');
    const broadcastId = parts[0];
    const buttonText = parts[1] || query.data;

    if (user && broadcastId) {
      try {
        db.prepare(`
          INSERT INTO button_clicks (broadcast_id, user_id, button_text)
          VALUES (?, ?, ?)
        `).run(Number(broadcastId), user.id, buttonText);
      } catch (err) {
        console.error('Tugma bosish yozilmadi:', err.message);
      }
    }

    bot.answerCallbackQuery(query.id, { text: 'Qabul qilindi ✓' }).catch(() => {});
  });

  bot.on('polling_error', (error) => {
    console.error('Polling xatosi:', error.message);
  });

  console.log('Telegram bot ishga tushdi...');
  return bot;
}

function getBot() {
  return bot;
}

// Inline keyboard tuzilmasini yaratish
// buttons: [[{ text, url? }]] — har bir ichki massiv bitta qatorni bildiradi
function buildInlineKeyboard(buttons, broadcastId) {
  if (!buttons || buttons.length === 0) return null;

  const keyboard = buttons.map((row) =>
    row.map((btn) => {
      if (btn.url) {
        return { text: btn.text, url: btn.url };
      }
      // callback_data uzunligi 64 baytdan oshmasligi kerak (Telegram cheklovi)
      const callbackData = `${broadcastId}::${btn.text}`.slice(0, 64);
      return { text: btn.text, callback_data: callbackData };
    })
  );

  return { inline_keyboard: keyboard };
}

// Xabarni bir foydalanuvchiga yuborish (matn, fayl va tugmalar bilan)
async function sendToUser(telegramId, { message, filePath, fileType, buttons, broadcastId }) {
  try {
    const replyMarkup = buildInlineKeyboard(buttons, broadcastId);
    const options = replyMarkup ? { reply_markup: replyMarkup } : {};

    if (filePath && fileType) {
      const captionOptions = { ...options, caption: message || undefined };
      if (fileType === 'photo') {
        await bot.sendPhoto(telegramId, filePath, captionOptions);
      } else if (fileType === 'video') {
        await bot.sendVideo(telegramId, filePath, captionOptions);
      } else {
        await bot.sendDocument(telegramId, filePath, captionOptions);
      }
    } else {
      await bot.sendMessage(telegramId, message, options);
    }

    return { success: true };
  } catch (err) {
    if (err.response && err.response.statusCode === 403) {
      db.prepare('UPDATE users SET is_blocked = 1 WHERE telegram_id = ?').run(telegramId);
    }
    return { success: false, error: err.message };
  }
}

module.exports = { initBot, getBot, sendToUser, buildInlineKeyboard };
