let authToken = localStorage.getItem('admin_token') || null;
let currentUser = JSON.parse(localStorage.getItem('admin_user') || 'null');

let allUsers = [];
let allGroups = [];
let selectedUserIds = new Set();
let targetMode = 'all';
let uploadedFile = null; // { filePath, fileType, originalName }
let buttonRowCount = 0;
let growthChart = null;
let modalEditingUserId = null;

// === Yordamchi funksiyalar ===
function showToast(msg, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.toggle('error', isError);
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

function apiFetch(url, options = {}) {
  return fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`,
      ...(options.headers || {})
    }
  });
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('uz-UZ') + ' ' + d.toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

// === Login / Logout ===
async function login() {
  const username = document.getElementById('username-input').value.trim();
  const password = document.getElementById('password-input').value;
  const errorEl = document.getElementById('login-error');
  errorEl.textContent = '';

  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();

    if (data.success) {
      authToken = data.token;
      currentUser = { username: data.username, role: data.role };
      localStorage.setItem('admin_token', authToken);
      localStorage.setItem('admin_user', JSON.stringify(currentUser));
      showApp();
    } else {
      errorEl.textContent = data.error || 'Login yoki parol noto\'g\'ri';
    }
  } catch (err) {
    errorEl.textContent = 'Serverga ulanishda xatolik';
  }
}

function logout() {
  localStorage.removeItem('admin_token');
  localStorage.removeItem('admin_user');
  authToken = null;
  document.getElementById('app').style.display = 'none';
  document.getElementById('login-screen').style.display = 'flex';
}

function showApp() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  document.getElementById('header-user').innerHTML =
    `${escapeHtml(currentUser.username)} <span class="role-badge">${currentUser.role === 'super_admin' ? 'Super-admin' : 'Admin'}</span>`;

  if (currentUser.role !== 'super_admin') {
    document.getElementById('admins-tab-btn').style.display = 'none';
  }

  addButtonRow(); // boshlanishida bo'sh bitta tugma qatori
  loadAll();
  setInterval(loadAll, 20000);
}

// === Tablar ===
function switchTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tabName));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === `tab-${tabName}`));
}

// === Ma'lumotlarni yuklash ===
async function loadAll() {
  await Promise.all([loadStats(), loadGrowthChart(), loadUsers(), loadGroups(), loadBroadcasts()]);
  if (currentUser.role === 'super_admin') loadAdmins();
}

async function loadStats() {
  const res = await apiFetch('/api/stats');
  if (!res.ok) return;
  const stats = await res.json();

  document.getElementById('stats-grid').innerHTML = `
    <div class="stat-card accent"><div class="num">${stats.activeUsers}</div><div class="label">Faol foydalanuvchi</div></div>
    <div class="stat-card"><div class="num">${stats.totalUsers}</div><div class="label">Jami foydalanuvchi</div></div>
    <div class="stat-card"><div class="num">${stats.blockedUsers}</div><div class="label">Bloklangan</div></div>
    <div class="stat-card"><div class="num">${stats.todayUsers}</div><div class="label">Bugun qo'shilgan</div></div>
    <div class="stat-card"><div class="num">${stats.totalBroadcasts}</div><div class="label">Yuborilgan xabar</div></div>
    <div class="stat-card warn"><div class="num">${stats.scheduledCount}</div><div class="label">Rejalashtirilgan</div></div>
  `;
}

async function loadGrowthChart() {
  const res = await apiFetch('/api/stats/daily-growth');
  if (!res.ok) return;
  const data = await res.json();

  const labels = data.map(d => d.day.slice(5)); // MM-DD
  const values = data.map(d => d.count);

  const ctx = document.getElementById('growth-chart');
  if (growthChart) {
    growthChart.data.labels = labels;
    growthChart.data.datasets[0].data = values;
    growthChart.update();
    return;
  }

  growthChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Yangi foydalanuvchilar',
        data: values,
        backgroundColor: '#4fd1c5',
        borderRadius: 4,
        maxBarThickness: 28
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#8b949e', font: { family: 'monospace', size: 11 } } },
        y: { beginAtZero: true, ticks: { color: '#8b949e', font: { family: 'monospace', size: 11 }, precision: 0 }, grid: { color: '#2a3441' } }
      }
    }
  });
}

async function loadUsers() {
  const res = await apiFetch('/api/users');
  if (!res.ok) return;
  allUsers = await res.json();

  document.getElementById('user-count-label').textContent = `${allUsers.length} foydalanuvchi`;
  document.getElementById('selected-count-label').textContent =
    selectedUserIds.size > 0 ? `(${selectedUserIds.size} ta tanlangan)` : '(hech kim tanlanmagan)';

  const tbody = document.getElementById('users-tbody');
  if (allUsers.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state">Hali foydalanuvchilar yo'q. Botga /start buyrug'ini yuborgan birinchi foydalanuvchi shu yerda ko'rinadi.</div></td></tr>`;
    return;
  }

  tbody.innerHTML = allUsers.map(u => {
    const groupTags = (u.groupIds || []).map(gid => {
      const g = allGroups.find(gr => gr.id === gid);
      return g ? `<span class="group-pill" style="color:${g.color}; border-color:${g.color}66;">${escapeHtml(g.name)}</span>` : '';
    }).join('');

    return `
      <tr>
        <td><input type="checkbox" class="user-checkbox" data-id="${u.id}" onchange="toggleUserSelect(${u.id})" ${selectedUserIds.has(u.id) ? 'checked' : ''}></td>
        <td>${escapeHtml(u.first_name || '—')} ${escapeHtml(u.last_name || '')}</td>
        <td>${u.username ? '@' + escapeHtml(u.username) : '—'}</td>
        <td>${groupTags || '<span style="color:var(--text-dim)">—</span>'}</td>
        <td>${u.is_blocked ? '<span class="tag blocked">Bloklangan</span>' : '<span class="tag active">Faol</span>'}</td>
        <td>${formatDate(u.joined_at)}</td>
        <td class="row-actions">
          <button onclick="openGroupModal(${u.id})">Guruhlar</button>
          <button onclick="toggleBlock(${u.id})">${u.is_blocked ? 'Blokdan chiqarish' : 'Bloklash'}</button>
          <button class="danger" onclick="deleteUser(${u.id})">O'chirish</button>
        </td>
      </tr>
    `;
  }).join('');
}

async function loadGroups() {
  const res = await apiFetch('/api/groups');
  if (!res.ok) return;
  allGroups = await res.json();

  // Xabar yuborish bo'limidagi guruh tanlash select'i
  const select = document.getElementById('target-group-select');
  select.innerHTML = allGroups.map(g => `<option value="${g.id}">${escapeHtml(g.name)} (${g.memberCount})</option>`).join('')
    || '<option value="">Guruh mavjud emas</option>';

  const tbody = document.getElementById('groups-tbody');
  if (allGroups.length === 0) {
    tbody.innerHTML = `<tr><td colspan="3"><div class="empty-state">Hali guruh yaratilmagan.</div></td></tr>`;
    return;
  }

  tbody.innerHTML = allGroups.map(g => `
    <tr>
      <td><span class="group-pill" style="color:${g.color}; border-color:${g.color}66;">${escapeHtml(g.name)}</span></td>
      <td>${g.memberCount}</td>
      <td class="row-actions"><button class="danger" onclick="deleteGroup(${g.id})">O'chirish</button></td>
    </tr>
  `).join('');
}

async function loadBroadcasts() {
  const res = await apiFetch('/api/broadcasts');
  if (!res.ok) return;
  const broadcasts = await res.json();

  const tbody = document.getElementById('broadcasts-tbody');
  if (broadcasts.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state">Hali xabarnoma yuborilmagan.</div></td></tr>`;
    return;
  }

  const statusLabels = { sent: 'Yuborildi', sending: 'Yuborilmoqda', scheduled: 'Rejalashtirilgan' };

  tbody.innerHTML = broadcasts.map(b => `
    <tr>
      <td style="max-width:240px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(b.message) || '<i style="color:var(--text-dim)">[fayl]</i>'}</td>
      <td><span class="tag ${b.status}">${statusLabels[b.status] || b.status}</span></td>
      <td>${b.sent_count}</td>
      <td>${b.failed_count}</td>
      <td>${b.clickCount}</td>
      <td>${b.status === 'scheduled' ? formatDate(b.scheduled_at) : formatDate(b.created_at)}</td>
      <td>${b.status === 'scheduled' ? `<button class="row-actions" style="background:none;border:1px solid var(--border);color:var(--danger);padding:4px 10px;border-radius:6px;font-size:11px;" onclick="cancelScheduled(${b.id})">Bekor qilish</button>` : ''}</td>
    </tr>
  `).join('');
}

async function loadAdmins() {
  const res = await apiFetch('/api/admins');
  if (!res.ok) return;
  const admins = await res.json();

  document.getElementById('admins-tbody').innerHTML = admins.map(a => `
    <tr>
      <td>${escapeHtml(a.username)}</td>
      <td><span class="tag role ${a.role === 'super_admin' ? 'super' : ''}">${a.role === 'super_admin' ? 'Super-admin' : 'Admin'}</span></td>
      <td>${formatDate(a.created_at)}</td>
      <td class="row-actions"><button class="danger" onclick="deleteAdmin(${a.id})">O'chirish</button></td>
    </tr>
  `).join('');
}

// === Foydalanuvchi amallari ===
async function toggleBlock(id) {
  const res = await apiFetch(`/api/users/${id}/toggle-block`, { method: 'POST' });
  if (res.ok) { showToast('Holat yangilandi'); loadUsers(); loadStats(); }
}

async function deleteUser(id) {
  if (!confirm('Bu foydalanuvchini o\'chirishni tasdiqlaysizmi?')) return;
  const res = await apiFetch(`/api/users/${id}`, { method: 'DELETE' });
  if (res.ok) { showToast('Foydalanuvchi o\'chirildi'); selectedUserIds.delete(id); loadUsers(); loadStats(); }
}

function toggleUserSelect(id) {
  selectedUserIds.has(id) ? selectedUserIds.delete(id) : selectedUserIds.add(id);
  document.getElementById('selected-count-label').textContent =
    selectedUserIds.size > 0 ? `(${selectedUserIds.size} ta tanlangan)` : '(hech kim tanlanmagan)';
}

function toggleSelectAll() {
  const checked = document.getElementById('select-all').checked;
  if (checked) allUsers.forEach(u => selectedUserIds.add(u.id));
  else selectedUserIds.clear();
  loadUsers();
}

// === Guruh modali ===
function openGroupModal(userId) {
  modalEditingUserId = userId;
  const user = allUsers.find(u => u.id === userId);
  const userGroupIds = new Set(user.groupIds || []);

  const chipsEl = document.getElementById('modal-group-chips');
  if (allGroups.length === 0) {
    chipsEl.innerHTML = '<span style="color:var(--text-dim); font-size:12px;">Avval "Guruhlar" bo\'limida guruh yarating.</span>';
  } else {
    chipsEl.innerHTML = allGroups.map(g => `
      <span class="group-chip ${userGroupIds.has(g.id) ? 'selected' : ''}" data-group-id="${g.id}" onclick="this.classList.toggle('selected')">${escapeHtml(g.name)}</span>
    `).join('');
  }

  document.getElementById('group-modal').classList.add('show');
}

function closeGroupModal() {
  document.getElementById('group-modal').classList.remove('show');
  modalEditingUserId = null;
}

async function saveUserGroups() {
  const selectedChips = document.querySelectorAll('#modal-group-chips .group-chip.selected');
  const groupIds = Array.from(selectedChips).map(c => Number(c.dataset.groupId));

  const res = await apiFetch(`/api/users/${modalEditingUserId}/groups`, {
    method: 'POST',
    body: JSON.stringify({ groupIds })
  });

  if (res.ok) {
    showToast('Guruhlar yangilandi');
    closeGroupModal();
    loadUsers();
    loadGroups();
  }
}

// === Guruhlar boshqaruvi ===
async function createGroup() {
  const name = document.getElementById('new-group-name').value.trim();
  const color = document.getElementById('new-group-color').value;
  if (!name) { showToast('Guruh nomini kiriting', true); return; }

  const res = await apiFetch('/api/groups', { method: 'POST', body: JSON.stringify({ name, color }) });
  const data = await res.json();

  if (res.ok) {
    showToast('Guruh yaratildi');
    document.getElementById('new-group-name').value = '';
    loadGroups();
  } else {
    showToast(data.error || 'Xatolik', true);
  }
}

async function deleteGroup(id) {
  if (!confirm('Bu guruhni o\'chirishni tasdiqlaysizmi?')) return;
  const res = await apiFetch(`/api/groups/${id}`, { method: 'DELETE' });
  if (res.ok) { showToast('Guruh o\'chirildi'); loadGroups(); loadUsers(); }
}

// === Adminlar boshqaruvi ===
async function createAdmin() {
  const username = document.getElementById('new-admin-username').value.trim();
  const password = document.getElementById('new-admin-password').value;
  const role = document.getElementById('new-admin-role').value;

  if (!username || !password) { showToast('Login va parolni kiriting', true); return; }

  const res = await apiFetch('/api/admins', { method: 'POST', body: JSON.stringify({ username, password, role }) });
  const data = await res.json();

  if (res.ok) {
    showToast('Admin qo\'shildi');
    document.getElementById('new-admin-username').value = '';
    document.getElementById('new-admin-password').value = '';
    loadAdmins();
  } else {
    showToast(data.error || 'Xatolik', true);
  }
}

async function deleteAdmin(id) {
  if (!confirm('Bu adminni o\'chirishni tasdiqlaysizmi?')) return;
  const res = await apiFetch(`/api/admins/${id}`, { method: 'DELETE' });
  const data = await res.json();
  if (res.ok) { showToast('Admin o\'chirildi'); loadAdmins(); }
  else showToast(data.error || 'Xatolik', true);
}

// === Xabar yuborish maqsadini tanlash ===
function setTargetMode(mode) {
  targetMode = mode;
  document.querySelectorAll('.target-tab').forEach(t => t.classList.toggle('active', t.dataset.target === mode));
  document.getElementById('target-group-picker').style.display = mode === 'group' ? 'block' : 'none';
  document.getElementById('target-selected-info').style.display = mode === 'selected' ? 'block' : 'none';

  const infoEl = document.getElementById('target-info');
  if (mode === 'all') infoEl.textContent = 'Barcha faol foydalanuvchilarga yuboriladi';
  else if (mode === 'group') infoEl.textContent = 'Tanlangan guruhga yuboriladi';
  else infoEl.textContent = `${selectedUserIds.size} ta tanlangan foydalanuvchiga yuboriladi`;
}

// === Fayl yuklash ===
async function handleFileSelect(event) {
  const file = event.target.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('file', file);

  showToast('Fayl yuklanmoqda...');

  try {
    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${authToken}` },
      body: formData
    });
    const data = await res.json();

    if (data.success) {
      uploadedFile = data;
      document.getElementById('file-preview-name').textContent = `📎 ${data.originalName} (${data.fileType})`;
      document.getElementById('file-preview').classList.add('show');
      showToast('Fayl yuklandi');
    } else {
      showToast(data.error || 'Fayl yuklanmadi', true);
    }
  } catch (err) {
    showToast('Fayl yuklashda xatolik', true);
  }
}

function removeFile() {
  uploadedFile = null;
  document.getElementById('file-input').value = '';
  document.getElementById('file-preview').classList.remove('show');
}

// === Tugma quruvchi ===
function addButtonRow() {
  buttonRowCount++;
  const id = buttonRowCount;
  const container = document.getElementById('button-rows');
  const row = document.createElement('div');
  row.className = 'button-row';
  row.id = `button-row-${id}`;
  row.innerHTML = `
    <input type="text" placeholder="Tugma matni" id="btn-text-${id}">
    <input type="text" placeholder="Havola (URL, ixtiyoriy)" id="btn-url-${id}">
    <button class="btn-icon danger" onclick="removeButtonRow(${id})">✕</button>
  `;
  container.appendChild(row);
}

function removeButtonRow(id) {
  const row = document.getElementById(`button-row-${id}`);
  if (row) row.remove();
}

function collectButtons() {
  const rows = document.querySelectorAll('.button-row');
  const buttons = [];
  rows.forEach(row => {
    const id = row.id.replace('button-row-', '');
    const text = document.getElementById(`btn-text-${id}`)?.value.trim();
    const url = document.getElementById(`btn-url-${id}`)?.value.trim();
    if (text) {
      buttons.push([{ text, url: url || undefined }]);
    }
  });
  return buttons;
}

// === Rejalashtirish toggle ===
function toggleSchedule() {
  const checked = document.getElementById('schedule-checkbox').checked;
  document.getElementById('schedule-fields').classList.toggle('show', checked);
}

// === Xabar yuborish ===
async function sendBroadcast() {
  const message = document.getElementById('broadcast-message').value.trim();
  const sendBtn = document.getElementById('send-btn');
  const buttons = collectButtons();
  const isScheduled = document.getElementById('schedule-checkbox').checked;

  if (!message && !uploadedFile) { showToast('Xabar matnini kiriting yoki fayl tanlang', true); return; }

  if (targetMode === 'selected' && selectedUserIds.size === 0) {
    showToast('Hech kim tanlanmagan. "Foydalanuvchilar" bo\'limidan tanlang.', true);
    return;
  }

  let scheduledAt = null;
  if (isScheduled) {
    const date = document.getElementById('schedule-date').value;
    const time = document.getElementById('schedule-time').value;
    if (!date || !time) { showToast('Sana va vaqtni to\'liq kiriting', true); return; }
    scheduledAt = new Date(`${date}T${time}`).toISOString();
    if (new Date(scheduledAt) <= new Date()) { showToast('Vaqt kelajakda bo\'lishi kerak', true); return; }
  }

  const payload = {
    message: message || null,
    buttons: buttons.length > 0 ? buttons : null,
    filePath: uploadedFile ? uploadedFile.filePath : null,
    fileType: uploadedFile ? uploadedFile.fileType : null,
    scheduledAt
  };

  if (targetMode === 'group') {
    const groupId = document.getElementById('target-group-select').value;
    if (!groupId) { showToast('Guruh tanlanmagan', true); return; }
    payload.groupId = Number(groupId);
  } else if (targetMode === 'selected') {
    payload.userIds = Array.from(selectedUserIds);
  }

  sendBtn.disabled = true;
  sendBtn.textContent = isScheduled ? 'Rejalashtirilmoqda...' : 'Yuborilmoqda...';

  try {
    const res = await apiFetch('/api/broadcast', { method: 'POST', body: JSON.stringify(payload) });
    const data = await res.json();

    if (data.success) {
      if (data.scheduled) {
        showToast('Xabar rejalashtirildi ✓');
      } else {
        showToast(`Yuborildi: ${data.sentCount}, Xatolik: ${data.failedCount}`);
      }
      document.getElementById('broadcast-message').value = '';
      removeFile();
      document.getElementById('button-rows').innerHTML = '';
      buttonRowCount = 0;
      addButtonRow();
      document.getElementById('schedule-checkbox').checked = false;
      toggleSchedule();
      selectedUserIds.clear();
      loadBroadcasts();
      loadStats();
      loadUsers();
    } else {
      showToast(data.error || 'Xatolik yuz berdi', true);
    }
  } catch (err) {
    showToast('Serverga ulanishda xatolik', true);
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = 'Yuborish';
  }
}

async function cancelScheduled(id) {
  if (!confirm('Rejalashtirilgan xabarni bekor qilasizmi?')) return;
  const res = await apiFetch(`/api/broadcasts/${id}`, { method: 'DELETE' });
  const data = await res.json();
  if (res.ok) { showToast('Bekor qilindi'); loadBroadcasts(); loadStats(); }
  else showToast(data.error || 'Xatolik', true);
}

// === Ilovani ishga tushirish ===
if (authToken && currentUser) {
  showApp();
}

document.getElementById('password-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') login();
});
